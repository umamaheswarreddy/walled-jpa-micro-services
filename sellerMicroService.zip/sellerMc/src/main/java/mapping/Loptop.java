package mapping;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
//@Table(name="laptops")
public class Loptop {
	@Id
	int lid;
	String lname;
	
	@ManyToOne
	Student student;

}
