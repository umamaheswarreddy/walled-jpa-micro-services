package mapping;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
//@Table(name="students")
public class Student {
	@Id
	int rollNo;
	String name;
	int marks;
	
//	@OneToMany(mappedBy = "student",cascade = CascadeType.ALL)
//	List<Loptop> laptop;

}
