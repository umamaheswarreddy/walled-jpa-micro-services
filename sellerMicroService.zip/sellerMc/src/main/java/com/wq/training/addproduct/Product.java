package com.wq.training.addproduct;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.wq.training.Sellers;

@Entity
@Table(name="product")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name = "PID")
	Integer id;
	
//	@Column(name="SBID")
	int subCategoryId;
	
//	@Column(name="CTID")
	int categoryId;
	
//	@Column(name="PRICE")
	double  price; 
	
//	@Column(name="PNM")
	String  itemName;
	
//	@Column(name="PDESC")
	String	description;
	
//	@Column(name="STOCK")
	int	stockNumber;
	
//	@Column(name="REM")
	String	remarks;
	
	@ManyToOne
	Sellers seller;

	public Sellers getSeller() {
		return seller;
	}

	public void setSeller(Sellers seller) {
		this.seller = seller;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Product(Integer id, int subCategoryId, int categoryId, double price, String itemName, String description,
			int stockNumber, String remarks,String SellerId) {
		super();
		this.id = id;
		this.subCategoryId = subCategoryId;
		this.categoryId = categoryId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
		
	}

	public Product() {
		super();
	}
	
	
	
	

}
