package com.wq.training.addproduct;

import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ProductRepository extends CrudRepository<Product, Integer> {
	
//	
//	@Query(value = "select stockNumber from product where id :id")
//    Product findOther(@Param(value = "id") int id);

	
	@Query(value = "select stock_number from Product p where p.id=:id", nativeQuery = true)
	int getStockById(@Param(value = "id") int id);
	
	
//	@Query(value =" UPDATE Product p SET p.stockNumber =:stockNumber WHERE p.id=:id")
//	void updateStock(@Param(value = "stockNumber") int stockNumber);

	
	
	Optional<Product> findByItemName(String itemName);
//	void deleteByItemName(String itemName);
	
//	@Query("delete from Book b where b.title=:title")
//	void deleteBooks(@Param("title") String title);
	
	@Transactional
	@Modifying
	@Query(value = "delete from product p where p.item_name=:itemName",nativeQuery = true)
	void deleteByItemName(@Param(value = "itemName") String itemName);
	
	
	
	
}
