package com.waq.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprDataApplication.class, args);
	}

}
