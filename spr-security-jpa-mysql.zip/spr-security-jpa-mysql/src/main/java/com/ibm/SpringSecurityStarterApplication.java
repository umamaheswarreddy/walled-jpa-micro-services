package com.ibm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityStarterApplication.class, args);
	}

}
