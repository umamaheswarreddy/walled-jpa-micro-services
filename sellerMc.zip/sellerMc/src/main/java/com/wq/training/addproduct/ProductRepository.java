package com.wq.training.addproduct;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends CrudRepository<Product, Integer> {
	
	
	@Query(value = "select stockNumber from product where id :id", nativeQuery = true)
    Product findOther(@Param(value = "id") int id);

	
	@Query(value = "select stockNumber from product where id :id", nativeQuery = true)
	int getStockById(@Param(value = "id") int id);

	
}
